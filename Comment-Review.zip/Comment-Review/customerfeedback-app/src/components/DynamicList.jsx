export default function DynamicList({ heading, values, setValues }) {

    const handleUpdate = (value, idx) => {
        const temp = [...values];
        temp[idx] = value;
        setValues(temp);
    };

    const addRow = () => {
        setValues((prev) => [...prev, ""]);
    };

    const deleteRow = (idx) => {
        setValues((prev) => prev.filter((_, i) => i !== idx));
    };

    return (
        <div className="dynamic-group">
            <label>{heading}</label>

            {values.map((val, i) => (
                <div key={i} className="dynamic-row">
                    <input
                        value={val}
                        onChange={(e) => handleUpdate(e.target.value, i)}
                    />

                    {i > 0 && (
                        <button
                            type="button"
                            className="remove-btn"
                            onClick={() => deleteRow(i)}
                        >
                            -
                        </button>
                    )}
                </div>
            ))}

            <button type="button" className="add-btn" onClick={addRow}>
                + Add
            </button>
        </div>
    );
}