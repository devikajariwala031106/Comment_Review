import FeedbackCard from "./FeedbackCard";

export default function FeedbackList({ feedbackList, deleteFeedback }) {

    if (feedbackList.length === 0) {
        return <p>No feedback submitted yet.</p>;
    }

    return (
        <div className="list">
            {feedbackList.map((entry) => (
                <FeedbackCard
                    key={entry.id}
                    feedback={entry}
                    removeEntry={deleteFeedback}
                />
            ))}
        </div>
    );
}