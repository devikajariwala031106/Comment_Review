import { useState, useRef } from "react";
import DynamicList from "./DynamicList";

const initialData = {
    name: "",
    email: "",
    category: "Bug",
    priority: "Low",
    description: "",
};

export default function FeedbackForm({ onSubmit }) {

    const [formData, setFormData] = useState(initialData);
    const [formErrors, setFormErrors] = useState({});
    const [stepsList, setStepsList] = useState([""]);
    const [suggestList, setSuggestList] = useState([""]);

    const screenshotInput = useRef();
    const notesInput = useRef();

    const checkValidation = (data = formData) => {

        const err = {};

        if (!data.name.trim()) err.name = "Required";

        if (!/\S+@\S+\.\S+/.test(data.email))
            err.email = "Invalid email";

        if (!data.description.trim() || data.description.trim().length < 10)
            err.description = "Min 10 characters";

        return err;
    };

    const handleInput = (ev) => {

        const { name, value } = ev.target;

        setFormData((prev) => {

            const updated = { ...prev, [name]: value };

            setFormErrors(checkValidation(updated));

            return updated;
        });
    };

    const isValid = Object.keys(checkValidation()).length === 0;

    const resetForm = () => {

        setFormData(initialData);
        setStepsList([""]);
        setSuggestList([""]);
        setFormErrors({});

        if (screenshotInput.current) screenshotInput.current.value = "";
        if (notesInput.current) notesInput.current.value = "";
    };

    const handleSubmit = (ev) => {

        ev.preventDefault();

        const err = checkValidation();

        setFormErrors(err);

        if (Object.keys(err).length !== 0) return;

        const newFeedback = {

            ...formData,

            steps: stepsList.filter((x) => x.trim()),

            suggestions: suggestList.filter((x) => x.trim()),

            screenshot: screenshotInput.current.value.trim(),

            notes: notesInput.current.value.trim(),
        };

        onSubmit(newFeedback);

        resetForm();
    };

    return (
        <form className="card" onSubmit={handleSubmit}>

            <h2 className="sub-title">Submit Feedback</h2>

            <label>Full Name *</label>

            <input
                name="name"
                value={formData.name}
                onChange={handleInput}
            />

            {formErrors.name && <p className="error">{formErrors.name}</p>}

            <label>Email *</label>

            <input
                name="email"
                value={formData.email}
                onChange={handleInput}
            />

            {formErrors.email && <p className="error">{formErrors.email}</p>}

            <label>Category</label>

            <select
                name="category"
                value={formData.category}
                onChange={handleInput}
            >
                <option>Bug</option>
                <option>Suggestion</option>
                <option>Complaint</option>
                <option>Other</option>
            </select>

            <label>Priority</label>

            <select
                name="priority"
                value={formData.priority}
                onChange={handleInput}
            >
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
            </select>

            <label>Description *</label>

            <textarea
                name="description"
                rows={3}
                value={formData.description}
                onChange={handleInput}
            />

            {formErrors.description && (
                <p className="error">{formErrors.description}</p>
            )}

            <DynamicList
                heading="Steps to Reproduce"
                values={stepsList}
                setValues={setStepsList}
            />

            <DynamicList
                heading="Suggested Improvements"
                values={suggestList}
                setValues={setSuggestList}
            />

            <label>Screenshot URL</label>

            <input ref={screenshotInput} />

            <label>Additional Notes</label>

            <textarea ref={notesInput} rows={2} />

            <button disabled={!isValid} className="btn">
                Submit
            </button>

        </form>
    );
}