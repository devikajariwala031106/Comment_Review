export default function FeedbackCard({ feedback, removeEntry }) {
    return (
        <div className="card feedback-card">

            <div className="row">
                <strong>{feedback.name}</strong>

                <button
                    className="delete-btn"
                    onClick={() => removeEntry(feedback.id)}
                >
                    Remove
                </button>
            </div>

            <p>{feedback.email}</p>

            <p>
                <span className="badge">{feedback.category}</span>{" "}
                <span className="badge priority">{feedback.priority}</span>
            </p>

            <p className="desc">{feedback.description}</p>

            {feedback.screenshot && (
                <a href={feedback.screenshot} target="_blank" rel="noopener noreferrer">           View Screenshot
                </a>
            )}

            {feedback.steps.length > 0 && (
                <div>
                    <h4>Steps</h4>
                    <ul>
                        {feedback.steps.map((s, i) => (
                            <li key={i}>{s}</li>
                        ))}
                    </ul>
                </div>
            )}

            {feedback.suggestions.length > 0 && (
                <div>
                    <h4>Suggestions</h4>
                    <ul>
                        {feedback.suggestions.map((s, i) => (
                            <li key={i}>{s}</li>
                        ))}
                    </ul>
                </div>
            )}

            {feedback.notes && (
                <p><strong>Notes:</strong> {feedback.notes}</p>
            )}

            <small className="time">{feedback.createdAt}</small>
        </div>
    );
}