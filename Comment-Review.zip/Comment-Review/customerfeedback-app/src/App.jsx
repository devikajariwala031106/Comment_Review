import { useState } from "react";
import FeedbackForm from "./components/FeedbackForm";
import FeedbackList from "./components/FeedbackList";

export default function App() {

  const [feedbackData, setFeedbackData] = useState([]);

  const addFeedback = (data) => {

    const newEntry = {
      id: Date.now(),
      createdAt: new Date().toLocaleString(),
      ...data
    };

    setFeedbackData((prev) => [newEntry, ...prev]);
  };

  const deleteFeedback = (id) => {

    setFeedbackData((prev) =>
      prev.filter((item) => item.id !== id)
    );
  };

  return (
    <div className="app-container">

      <h1 className="title">
        Customer Feedback & Issue Reporting
      </h1>

      <div className="layout">

        <div className="left-section">
          <FeedbackForm onSubmit={addFeedback} />
        </div>

        <div className="right-section">

          <h2 className="sub-title">
            Feedback Dashboard ({feedbackData.length})
          </h2>

          <FeedbackList
            feedbackList={feedbackData}
            deleteFeedback={deleteFeedback}
          />

        </div>

      </div>

    </div>
  );
}